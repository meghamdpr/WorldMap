package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoForApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoForApiApplication.class, args);
	}

}
