export interface Icontinent{
    place: string,
    parent: string,
    children: string[]
}