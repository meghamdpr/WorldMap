export class Region{

    place!: String;
    parent!: String;
    children!: any[];

    constructor( ){

    }
}